# UI-LoginApp

The article : 
[How to Create User Interface Login & Register with Android Studio](https://medium.com/muhamadjalaludin/how-to-create-user-interface-login-register-with-android-studio-34da847b05b2)
